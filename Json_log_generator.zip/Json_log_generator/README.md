# jsonevent-producer
Utility project to simulate log events
